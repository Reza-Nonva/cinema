-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: focused_driscoll
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `focused_driscoll`
--

/*!40000 DROP DATABASE IF EXISTS `focused_driscoll`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `focused_driscoll` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `focused_driscoll`;

--
-- Table structure for table `card_bank`
--

DROP TABLE IF EXISTS `card_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_bank` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `number` varchar(16) NOT NULL,
  `cvv` bigint NOT NULL,
  `date` date NOT NULL,
  `password` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `card_bank_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_bank`
--

LOCK TABLES `card_bank` WRITE;
/*!40000 ALTER TABLE `card_bank` DISABLE KEYS */;
INSERT INTO `card_bank` VALUES ('5528aec8-ca4c-11ee-a7a0-0242ac113f02',4,'d33c8c64-ca4b-11ee-a7a0-0242ac113f02','6362141809960843',123,'2020-12-01',8765),('e7e8c3a3-ca7f-11ee-a7a0-0242ac113f02',7,'d9122005-ca77-11ee-a7a0-0242ac113f02','6219861903581766',473,'1381-10-10',2554),('1d7d3591-cdb2-11ee-a7a0-0242ac113f02',8,'390bdc2a-cdaf-11ee-a7a0-0242ac113f02','6037991774256220',473,'1402-10-10',5428),('de050c28-cdb2-11ee-a7a0-0242ac113f02',9,'390bdc2a-cdaf-11ee-a7a0-0242ac113f02','5041721077801851',473,'1403-10-10',5441);
/*!40000 ALTER TABLE `card_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT (uuid()),
  `movie_id` char(36) DEFAULT (uuid()),
  `parent_comment_id` int DEFAULT NULL,
  `comment_text` text,
  `create_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `movie_id` (`movie_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`),
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,'d9122005-ca77-11ee-a7a0-0242ac113f02','8cd52564-ca91-11ee-a7a0-0242ac113f02',0,'abbas','2024-02-17'),(2,'ba68aabc-cdb9-11ee-a7a0-0242ac113f02','e12f478d-cdb9-11ee-a7a0-0242ac113f02',0,'gholamreza','2024-02-17');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `year` bigint NOT NULL,
  `age_range` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `movie_uuid_index` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES ('08d6c4e1-ca42-11ee-a7a0-0242ac113f02',2,'inception',2016,18),('bf8d975b-ca43-11ee-a7a0-0242ac113f02',3,'The Shawshank Redemption',1994,18),('8cd52564-ca91-11ee-a7a0-0242ac113f02',4,'gham',2020,18),('7cb57f5f-cdad-11ee-a7a0-0242ac113f02',5,'charkhoneh',2020,18),('e12f478d-cdb9-11ee-a7a0-0242ac113f02',6,'sakhteman',2020,15);
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan`
--

DROP TABLE IF EXISTS `plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `plan_id` varchar(255) NOT NULL,
  `start_time` datetime NOT NULL,
  `finish_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `plan_users_uuid_fk` (`user_id`),
  KEY `plan_uuid_index` (`uuid`),
  CONSTRAINT `plan_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan`
--

LOCK TABLES `plan` WRITE;
/*!40000 ALTER TABLE `plan` DISABLE KEYS */;
INSERT INTO `plan` VALUES ('d3b87576-ca4b-11ee-a7a0-0242ac113f02',9,'d33c8c64-ca4b-11ee-a7a0-0242ac113f02','1','2024-02-13 09:42:32','2024-03-15 09:42:32'),('d949edac-ca77-11ee-a7a0-0242ac113f02',10,'d9122005-ca77-11ee-a7a0-0242ac113f02','1','2024-02-13 17:27:39','2024-03-15 17:27:39'),('d5b906a5-ca8b-11ee-a7a0-0242ac113f02',11,'d56e9e36-ca8b-11ee-a7a0-0242ac113f02','1','2024-02-13 19:50:43','2024-03-15 19:50:43'),('19392979-cda9-11ee-a7a0-0242ac113f02',12,'190f5f14-cda9-11ee-a7a0-0242ac113f02','1','2024-02-17 18:57:45','2024-03-19 18:57:45'),('355c1e49-cdaa-11ee-a7a0-0242ac113f02',13,'34fe1451-cdaa-11ee-a7a0-0242ac113f02','1','2024-02-17 19:05:42','2024-03-19 19:05:42'),('395183f0-cdaf-11ee-a7a0-0242ac113f02',14,'390bdc2a-cdaf-11ee-a7a0-0242ac113f02','1','2024-02-17 19:41:36','2024-03-19 19:41:36'),('bac66517-cdb9-11ee-a7a0-0242ac113f02',15,'ba68aabc-cdb9-11ee-a7a0-0242ac113f02','1','2024-02-17 20:56:48','2024-03-19 20:56:48');
/*!40000 ALTER TABLE `plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan_transaction`
--

DROP TABLE IF EXISTS `plan_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_transaction` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` char(36) NOT NULL,
  `payment_code` bigint NOT NULL,
  `date` datetime NOT NULL,
  `user_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `plan_transaction_plan_id_index` (`plan_id`),
  KEY `plan_transaction_users_uuid_fk` (`user_id`),
  CONSTRAINT `plan_transaction_plan_uuid_fk` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`uuid`),
  CONSTRAINT `plan_transaction_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_transaction`
--

LOCK TABLES `plan_transaction` WRITE;
/*!40000 ALTER TABLE `plan_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `plan_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rank`
--

DROP TABLE IF EXISTS `rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rank` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` int NOT NULL AUTO_INCREMENT,
  `rating` int DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `movie_id` char(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rank_movie_uuid_fk` (`movie_id`),
  KEY `rank_users_uuid_fk` (`user_id`),
  CONSTRAINT `rank_movie_uuid_fk` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`uuid`),
  CONSTRAINT `rank_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`),
  CONSTRAINT `rank_chk_1` CHECK (((`rating` >= 1) and (`rating` <= 5)))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rank`
--

LOCK TABLES `rank` WRITE;
/*!40000 ALTER TABLE `rank` DISABLE KEYS */;
INSERT INTO `rank` VALUES ('58a4a9ea-caa0-11ee-a7a0-0242ac113f02',2,4,'d9122005-ca77-11ee-a7a0-0242ac113f02','8cd52564-ca91-11ee-a7a0-0242ac113f02'),('bd861d85-cdbb-11ee-a7a0-0242ac113f02',3,4,'ba68aabc-cdb9-11ee-a7a0-0242ac113f02','e12f478d-cdb9-11ee-a7a0-0242ac113f02'),('8682b036-cdbc-11ee-a7a0-0242ac113f02',4,2,'d56e9e36-ca8b-11ee-a7a0-0242ac113f02','e12f478d-cdb9-11ee-a7a0-0242ac113f02');
/*!40000 ALTER TABLE `rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screen_transaction`
--

DROP TABLE IF EXISTS `screen_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `screen_transaction` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` int NOT NULL AUTO_INCREMENT,
  `screen_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `payment_code` varchar(36) NOT NULL,
  `buy_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_code` (`payment_code`),
  KEY `screen_transaction_users_uuid_fk` (`user_id`),
  KEY `screen_transaction_screening_uuid_fk` (`screen_id`),
  CONSTRAINT `screen_transaction_screening_uuid_fk` FOREIGN KEY (`screen_id`) REFERENCES `screening` (`uuid`),
  CONSTRAINT `screen_transaction_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screen_transaction`
--

LOCK TABLES `screen_transaction` WRITE;
/*!40000 ALTER TABLE `screen_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `screen_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `screening`
--

DROP TABLE IF EXISTS `screening`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `screening` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `movie_id` char(36) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `price` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `screening_movie_uuid_fk` (`movie_id`),
  KEY `screening_uuid_index` (`uuid`),
  CONSTRAINT `screening_movie_uuid_fk` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `screening`
--

LOCK TABLES `screening` WRITE;
/*!40000 ALTER TABLE `screening` DISABLE KEYS */;
INSERT INTO `screening` VALUES ('e39db067-ca44-11ee-a7a0-0242ac113f02',16,'08d6c4e1-ca42-11ee-a7a0-0242ac113f02','2024-10-10 20:00:00','2024-02-06 21:30:00',100),('8b03f381-ca4e-11ee-a7a0-0242ac113f02',17,'08d6c4e1-ca42-11ee-a7a0-0242ac113f02','2024-10-10 20:00:00','2024-02-06 21:30:00',100),('411b1538-ca95-11ee-a7a0-0242ac113f02',18,'8cd52564-ca91-11ee-a7a0-0242ac113f02','2024-10-10 20:00:00','2024-10-10 21:30:00',400),('40441744-cdba-11ee-a7a0-0242ac113f02',19,'e12f478d-cdb9-11ee-a7a0-0242ac113f02','2024-10-10 20:00:00','2024-10-10 21:30:00',250),('065e55b1-cdbd-11ee-a7a0-0242ac113f02',20,'e12f478d-cdb9-11ee-a7a0-0242ac113f02','2024-10-10 20:00:00','2024-10-10 22:30:00',310);
/*!40000 ALTER TABLE `screening` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `screen_id` char(36) NOT NULL,
  `chair_number` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_screening_uuid_fk` (`screen_id`),
  KEY `ticket_users_uuid_fk` (`user_id`),
  CONSTRAINT `ticket_screening_uuid_fk` FOREIGN KEY (`screen_id`) REFERENCES `screening` (`uuid`),
  CONSTRAINT `ticket_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES ('091714a9-ca86-11ee-a7a0-0242ac113f02',21,'d33c8c64-ca4b-11ee-a7a0-0242ac113f02','e39db067-ca44-11ee-a7a0-0242ac113f02',35),('53ba72a0-ca86-11ee-a7a0-0242ac113f02',22,'d9122005-ca77-11ee-a7a0-0242ac113f02','e39db067-ca44-11ee-a7a0-0242ac113f02',35),('798ef1c8-cdb6-11ee-a7a0-0242ac113f02',25,'d9122005-ca77-11ee-a7a0-0242ac113f02','411b1538-ca95-11ee-a7a0-0242ac113f02',27);
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile_number` varchar(11) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `register_date` date NOT NULL,
  `last_login_date` date NOT NULL,
  `last_login_time` time NOT NULL,
  `plan` int DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('d33c8c64-ca4b-11ee-a7a0-0242ac113f02',29,'Yashar23','eeebfa5c4ee341c3a54c6485fad270c70847049393d19516182d51a39b39a8be','Yashar1989112@gmail.com','09213840549','1368-05-23','2024-02-13','2024-02-13','10:06:12',NULL,0),('d9122005-ca77-11ee-a7a0-0242ac113f02',30,'Reza6','b01c702f0414e2264e520a69551e568dbd3be43e48385c1543619f772165b44c','reza.miraki81@gmail.com','09140971694','1379-02-17','2024-02-13','2024-02-17','20:51:21',NULL,0),('d56e9e36-ca8b-11ee-a7a0-0242ac113f02',31,'Reza2','36ed79f33f4fddfa0591d761a2ce80b99d1b033b973b2a7a0cbfaf49394ff452','reza.miraki4567@gmail.com','09140521445','1381-10-10','2024-02-13','2024-02-17','21:15:16',NULL,1),('190f5f14-cda9-11ee-a7a0-0242ac113f02',32,'Reza542','36ed79f33f4fddfa0591d761a2ce80b99d1b033b973b2a7a0cbfaf49394ff452','reza.mirakii1234@gmail.com','09140971694','1351-10-10','2024-02-17','2024-02-17','18:57:45',NULL,0),('34fe1451-cdaa-11ee-a7a0-0242ac113f02',33,'Mosa542','36ed79f33f4fddfa0591d761a2ce80b99d1b033b973b2a7a0cbfaf49394ff452','reza.miraki4235@gmail.com','09138767578','1381-10-10','2024-02-17','2024-02-17','19:05:41',1,0),('390bdc2a-cdaf-11ee-a7a0-0242ac113f02',34,'Reza1254','b01c702f0414e2264e520a69551e568dbd3be43e48385c1543619f772165b44c','reza.miraki1245543@gmail.com','09136501398','1381-10-10','2024-02-17','2024-02-17','20:19:41',1,0),('ba68aabc-cdb9-11ee-a7a0-0242ac113f02',35,'Reza369','36ed79f33f4fddfa0591d761a2ce80b99d1b033b973b2a7a0cbfaf49394ff452','reza.miraki12423@gmail.com','09135421478','1381-10-19','2024-02-17','2024-02-17','21:10:18',1,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet`
--

DROP TABLE IF EXISTS `wallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet` (
  `uuid` char(36) NOT NULL DEFAULT (uuid()),
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) NOT NULL,
  `balance` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `wallet_users_uuid_fk` (`user_id`),
  CONSTRAINT `wallet_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet`
--

LOCK TABLES `wallet` WRITE;
/*!40000 ALTER TABLE `wallet` DISABLE KEYS */;
INSERT INTO `wallet` VALUES ('d37ec398-ca4b-11ee-a7a0-0242ac113f02',9,'d33c8c64-ca4b-11ee-a7a0-0242ac113f02',110000),('d93407b7-ca77-11ee-a7a0-0242ac113f02',10,'d9122005-ca77-11ee-a7a0-0242ac113f02',99100),('d5a6312b-ca8b-11ee-a7a0-0242ac113f02',11,'d56e9e36-ca8b-11ee-a7a0-0242ac113f02',0),('1925c0a2-cda9-11ee-a7a0-0242ac113f02',12,'190f5f14-cda9-11ee-a7a0-0242ac113f02',0),('3525cf98-cdaa-11ee-a7a0-0242ac113f02',13,'34fe1451-cdaa-11ee-a7a0-0242ac113f02',0),('39331db1-cdaf-11ee-a7a0-0242ac113f02',14,'390bdc2a-cdaf-11ee-a7a0-0242ac113f02',80000),('ba98b184-cdb9-11ee-a7a0-0242ac113f02',15,'ba68aabc-cdb9-11ee-a7a0-0242ac113f02',0);
/*!40000 ALTER TABLE `wallet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_transaction`
--

DROP TABLE IF EXISTS `wallet_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet_transaction` (
  `uuid` char(36) DEFAULT (uuid()),
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payment_code` bigint NOT NULL,
  `card_id` varchar(16) NOT NULL,
  `date` datetime NOT NULL,
  `pay_type` bigint NOT NULL,
  `user_id` char(36) NOT NULL,
  `amount` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `card_id` (`card_id`),
  KEY `wallet_transaction_users_uuid_fk` (`user_id`),
  CONSTRAINT `wallet_transaction_ibfk_2` FOREIGN KEY (`card_id`) REFERENCES `card_bank` (`number`),
  CONSTRAINT `wallet_transaction_users_uuid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_transaction`
--

LOCK TABLES `wallet_transaction` WRITE;
/*!40000 ALTER TABLE `wallet_transaction` DISABLE KEYS */;
INSERT INTO `wallet_transaction` VALUES ('23369639-ca4e-11ee-a7a0-0242ac113f02',36,51834278376058712,'6362141809960843','2024-02-13 09:59:04',1,'d33c8c64-ca4b-11ee-a7a0-0242ac113f02',110000),('71d426fe-ca82-11ee-a7a0-0242ac113f02',37,1002949769553479449,'6219861903581766','2024-02-13 18:43:29',1,'d9122005-ca77-11ee-a7a0-0242ac113f02',50000),('c1a4ccdd-ca83-11ee-a7a0-0242ac113f02',38,2087101769645263180,'6219861903581766','2024-02-13 18:52:52',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('035df03c-ca84-11ee-a7a0-0242ac113f02',39,370059331733522875,'6219861903581766','2024-02-13 18:54:43',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('683de90f-ca84-11ee-a7a0-0242ac113f02',40,959279916477287012,'6219861903581766','2024-02-13 18:57:32',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('870f74f0-ca84-11ee-a7a0-0242ac113f02',41,282231442418403992,'6219861903581766','2024-02-13 18:58:24',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('b6163411-ca85-11ee-a7a0-0242ac113f02',42,1195406085856136340,'6219861903581766','2024-02-13 19:06:52',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('09037e58-ca86-11ee-a7a0-0242ac113f02',43,1480106479926873375,'6219861903581766','2024-02-13 19:09:11',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('53a691d0-ca86-11ee-a7a0-0242ac113f02',44,1977861990890835356,'6219861903581766','2024-02-13 19:11:16',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('67d9123c-ca86-11ee-a7a0-0242ac113f02',45,1720548232444743102,'6219861903581766','2024-02-13 19:11:50',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-100),('4bcc2daa-ca8a-11ee-a7a0-0242ac113f02',46,23687330460832838,'6219861903581766','2024-02-13 19:39:42',1,'d9122005-ca77-11ee-a7a0-0242ac113f02',100),('dcca94ca-cdab-11ee-a7a0-0242ac113f02',47,71813504164746515,'6219861903581766','2024-02-17 19:17:31',1,'d9122005-ca77-11ee-a7a0-0242ac113f02',50000),('5ad21d50-cdb2-11ee-a7a0-0242ac113f02',48,1299970741169610744,'6037991774256220','2024-02-17 20:04:00',1,'390bdc2a-cdaf-11ee-a7a0-0242ac113f02',80000),('c8346fdd-cdb5-11ee-a7a0-0242ac113f02',49,1371751258277340600,'6219861903581766','2024-02-17 20:28:32',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-400),('ebf7752e-cdb5-11ee-a7a0-0242ac113f02',50,1358398789069628916,'6219861903581766','2024-02-17 20:29:32',1,'d9122005-ca77-11ee-a7a0-0242ac113f02',400),('7977b03a-cdb6-11ee-a7a0-0242ac113f02',51,1765817382397666,'6219861903581766','2024-02-17 20:33:30',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-400),('fd19acb3-cdb8-11ee-a7a0-0242ac113f02',52,1877227539891546905,'6219861903581766','2024-02-17 20:51:29',0,'d9122005-ca77-11ee-a7a0-0242ac113f02',-200),('68a458f8-cdb9-11ee-a7a0-0242ac113f02',53,540208756132211662,'6219861903581766','2024-02-17 20:54:30',1,'d9122005-ca77-11ee-a7a0-0242ac113f02',400);
/*!40000 ALTER TABLE `wallet_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'focused_driscoll'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-01 23:00:01
